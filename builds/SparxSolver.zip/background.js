// background.js

// Provider configuration - all OpenAI-compatible
const PROVIDERS = {
  openrouter: {
    name: "OpenRouter",
    baseUrl: "https://openrouter.ai/api/v1",
    models: ["openrouter/free"],
  },
  gemini: {
    name: "Gemini",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    models: [
      "gemini-3.1-flash-lite-preview",
      "gemini-2.5-flash-lite",
      "gemma-3-27b-it"
    ],
  },
  mistral: {
    name: "Mistral",
    baseUrl: "https://api.mistral.ai/v1",
    models: ["mistral-medium-latest"],
  },
};

// Function to load system prompt from file
async function loadSystemPrompt() {
  try {
    const url = chrome.runtime.getURL("systemprompt.txt");
    const response = await fetch(url);
    return await response.text();
  } catch (error) {
    console.error("Failed to load system prompt:", error);
    return "You are an expert AI assistant configured to solve UK GCSE Maths problems."; // Fallback prompt
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "solveMath") {
    captureAndProcessScreenshot(sendResponse);
    return true;
  }
  
  // This block safely routes BOTH normal image questions AND your new bookwork flow
  if (request.action === "chooseImageAnswer") {
    chooseImageAnswer(request, sendResponse);
    return true;
  }
  
  if (request.action === "saveBookwork") {
    if (request.code && request.url) {
      chrome.storage.local.get("bookworks", (data) => {
        const bookworks = data.bookworks || {};
        bookworks[request.code] = request.url;
        chrome.storage.local.set({ bookworks: bookworks }, () => {
          console.log(`[Background] Saved bookwork: ${request.code}`);
          sendResponse({ status: "success", code: request.code });
        });
      });
    }
    return true;
  }

  // --- CORRECT ARCHITECTURE: Relay the loop trigger directly to your UI Extension Popup ---
  if (request.action === "requestNextAnswer") {
    console.log("[Background] Auto-solve loop verified active. Relaying initialization command to Popup UI...");
    chrome.runtime.sendMessage({ action: "triggerPopupSolvePipeline" });
    sendResponse({ status: "Relay sequence engaged" });
    return true;
  }
});

function extractImageChoiceIndex(responseText, choiceCount) {
  const matches = String(responseText).match(/-?\d+(\.\d+)?/g);
  if (!matches) return null;

  const parsed = Number(matches[matches.length - 1]);
  if (!Number.isInteger(parsed)) return null;
  if (parsed < 1 || parsed > choiceCount) return null;
  return parsed;
}

function extractProviderTextContent(content) {
  if (typeof content === "string") {
    return content;
  }

  if (Array.isArray(content)) {
    return content
      .map((part) => (typeof part?.text === "string" ? part.text : ""))
      .join("");
  }

  return "";
}

async function getProviderSettings() {
  const {
    apiKey: storedApiKey,
    provider: storedProvider,
    model: storedModel,
  } = await new Promise((resolve) =>
    chrome.storage.local.get(["apiKey", "provider", "model"], resolve)
  );

  if (!storedApiKey || !storedProvider || (!storedModel && !PROVIDERS[storedProvider]?.models)) {
    let missingFields = [];
    if (!storedProvider) missingFields.push("Provider");
    if (!storedApiKey) missingFields.push("API Key");
    if (!storedModel && !PROVIDERS[storedProvider]?.models) missingFields.push("Model");
    throw new Error(
      `Missing configuration: ${missingFields.join(", ")}. Please set them in the extension popup before solving problems.`
    );
  }

  const providerConfig = PROVIDERS[storedProvider];
  if (!providerConfig) {
    const availableProviders = Object.keys(PROVIDERS).join(", ");
    throw new Error(
      `Unknown provider "${storedProvider}". Available providers: ${availableProviders}. Please select a valid provider in the extension settings.`
    );
  }

  const modelsToTry =
    providerConfig.models && providerConfig.models.length > 0
      ? providerConfig.models
      : [storedModel];

  return {
    apiKey: storedApiKey,
    provider: storedProvider,
    providerConfig,
    modelsToTry,
  };
}

async function chooseImageAnswer(request, sendResponse) {
  try {
    const { finalAnswer, imageDataUrl, choiceCount, isBookwork } = request;
    if (!finalAnswer || !imageDataUrl || !choiceCount) {
      sendResponse({
        error: "Missing parameters for image answer selection.",
      });
      return;
    }

    const { apiKey, providerConfig, modelsToTry } = await getProviderSettings();
    
    let prompt = "";
    let messagesContent = [];

    if (isBookwork === true) {
      prompt = `You are performing a bookwork check verification. Look closely at the two images provided below:\n` +
               `Image 1 is the CORRECT reference answer.\n` +
               `Image 2 contains all the numbered options (numbered 1 to ${choiceCount}).\n\n` +
               `Task: Find which option in Image 2 exactly matches the reference solution in Image 1. Return ONLY the integer number of the matching option. Do not include any other text.`;

      messagesContent = [
        { type: "text", text: prompt },
        {
          type: "image_url",
          image_url: { url: finalAnswer },
        },
        {
          type: "image_url",
          image_url: { url: imageDataUrl },
        }
      ];
    } else {
      prompt = `Given this final answer and the image of numbered choices, return only the number of the image that best fits the answer. ` +
               `Images are numbered from 1 in their current order. There are ${choiceCount} images.  ${finalAnswer}`;
      
      messagesContent = [
        { type: "text", text: prompt },
        {
          type: "image_url",
          image_url: { url: imageDataUrl },
        }
      ];
    }

    let response = null;
    let fetchError = null;

    for (const modelToTry of modelsToTry) {
      const requestBody = {
        model: modelToTry,
        messages: [
          {
            role: "user",
            content: messagesContent,
          },
        ],
        max_tokens: 100,
        temperature: 0,
      };

      // ---- DETAILED INSPECTION LOGS ----
      console.log("%c[SparxSolver LLM Outbound Payload]", "color: #00ffcc; font-weight: bold;");
      console.log("Target Model:", modelToTry);
      console.log("Prompt Instructions:", prompt);
      
      if (isBookwork) {
        console.log("Image 1 (Reference Answer URL):", finalAnswer);
        // This log makes the massive base64 string a cleanly formatted, collapsible object item in DevTools
        console.log("Image 2 (Choices Grid Base64):", { dataUrl: imageDataUrl });
      } else {
        console.log("Target Solution Text:", finalAnswer);
        console.log("Choices Grid Base64:", { dataUrl: imageDataUrl });
      }
      // ----------------------------------

      try {
        const res = await fetch(`${providerConfig.baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify(requestBody),
        });

        if (res.ok) {
          response = res;
          break;
        }

        response = res;
        console.warn(`[SparxSolver] Model ${modelToTry} failed with status ${res.status}.`);
      } catch (err) {
        fetchError = err;
        console.warn(`[SparxSolver] Model ${modelToTry} fetch error:`, err);
      }
    }

    if (fetchError && !response) throw fetchError;

    if (!response || !response.ok) {
      const status = response ? response.status : 0;
      sendResponse({ error: `Image answer request failed with status ${status}` });
      return;
    }

    const responseData = await response.json();
    const rawText = extractProviderTextContent(responseData.choices?.[0]?.message?.content);
    const choiceIndex = extractImageChoiceIndex(rawText, choiceCount);

    if (choiceIndex === null || choiceIndex === undefined) {
      sendResponse({
        error: `Could not extract choice index from response: ${rawText}`,
        rawText,
      });
      return;
    }

    sendResponse({ rawText, choiceIndex });
  } catch (error) {
    console.error("[SparxSolver] Image answer selection failed:", error);
    sendResponse({ error: error.message || "Selection error." });
  }
}

chrome.runtime.onConnect.addListener(function (port) {
  if (port.name === "solveMathStream") {
    port.onMessage.addListener(async function (msg) {
      if (msg.action === "solveMath") {
        let requestTimeout = null;
        let storedProvider = null;
        try {
          // Fetch API Key, provider, and model from storage
          const {
            apiKey: storedApiKey,
            provider,
            model: storedModel,
          } = await new Promise((resolve) =>
            chrome.storage.local.get(
              ["apiKey", "provider", "model"],
              resolve
            )
          );
          storedProvider = provider;

          if (!storedApiKey || !storedProvider || (!storedModel && !PROVIDERS[storedProvider]?.models)) {
            let missingFields = [];
            if (!storedProvider) missingFields.push("Provider");
            if (!storedApiKey) missingFields.push("API Key");
            if (!storedModel && !PROVIDERS[storedProvider]?.models) missingFields.push("Model");

            port.postMessage({
              error:
                `Missing configuration: ${missingFields.join(", ")}. Please set them in the extension popup before solving problems.`,
            });
            port.disconnect();
            return;
          }

          const providerConfig = PROVIDERS[storedProvider];
          if (!providerConfig) {
            const availableProviders = Object.keys(PROVIDERS).join(", ");
            port.postMessage({
              error: `Unknown provider "${storedProvider}". Available providers: ${availableProviders}. Please select a valid provider in the extension settings.`,
            });
            port.disconnect();
            return;
          }

          // 1. Request screenshot of the question element from content script
          const [tab] = await chrome.tabs.query({
            active: true,
            currentWindow: true,
          });
          if (!tab || !tab.id) {
            port.postMessage({
              error: "No active tab found. Please open a Sparx Learning page and make sure the extension has access to it.",
            });
            port.disconnect();
            return;
          }
          const dataUrlResponse = await new Promise((resolve) => {
            chrome.tabs.sendMessage(
              tab.id,
              { action: "captureQuestionScreenshot" },
              (response) => resolve(response)
            );
          });
          if (!dataUrlResponse || dataUrlResponse.error) {
            port.postMessage({
              error:
                dataUrlResponse?.error ||
                "Failed to capture screenshot of the question. This may happen if: 1) The content script is not loaded, 2) You're on an unsupported page, or 3) The question element is not visible. Please refresh the page and try again.",
            });
            port.disconnect();
            return;
          }
          const dataUrl = dataUrlResponse.dataUrl;
          const base64ImageData = dataUrl.split(",")[1];

          const detailedPrompt = await loadSystemPrompt();

          let modelsToTry = providerConfig.models && providerConfig.models.length > 0
            ? providerConfig.models
            : [storedModel];

          let response = null;
          let fetchError = null;
          const requestController = new AbortController();
          requestTimeout = setTimeout(() => requestController.abort(), 60000);

          for (const modelToTry of modelsToTry) {
            const requestBody = {
              model: modelToTry,
              messages: [
                {
                  role: "system",
                  content: detailedPrompt,
                },
                {
                  role: "user",
                  content: [
                    {
                      type: "image_url",
                      image_url: {
                        url: `data:image/png;base64,${base64ImageData}`,
                      },
                    },
                  ],
                },
              ],
              stream: true,
              max_tokens: 4096,
              temperature: 0.3,
            };

            try {
              // 2. Stream API Call (OpenAI-compatible format)
              const res = await fetch(
                `${providerConfig.baseUrl}/chat/completions`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${storedApiKey}`,
                  },
                  signal: requestController.signal,
                  body: JSON.stringify(requestBody),
                }
              );

              if (res.ok && res.body) {
                response = res;
                break; // Success, exit the loop
              } else {
                response = res; // Keep the last failed response for error handling
                console.warn(`[SparxSolver] Model ${modelToTry} failed with status ${res.status}. Falling back if available...`);
              }
            } catch (err) {
              fetchError = err;
              console.warn(`[SparxSolver] Model ${modelToTry} fetch error:`, err);
            }
          }

          if (fetchError && !response) {
            throw fetchError;
          }

          if (!response || !response.ok || !response.body) {
            clearTimeout(requestTimeout);
            requestTimeout = null;
            let errorDetails = "";
            let status = response ? response.status : 0;
            let statusText = response ? response.statusText : "";

            if (status === 401 || status === 403) {
              errorDetails = `Authentication failed. Your API key for ${PROVIDERS[storedProvider]?.name} is invalid or expired. Please update it in the extension settings.`;
            } else if (status === 429) {
              errorDetails = `Rate limit exceeded. ${PROVIDERS[storedProvider]?.name} is throttling requests. Please wait a moment and try again.`;
            } else if (status >= 500) {
              errorDetails = `${PROVIDERS[storedProvider]?.name} server error (${status}). The service may be temporarily unavailable. Please try again later.`;
            } else if (response && !response.body) {
              errorDetails = `API request failed: No response body received from ${PROVIDERS[storedProvider]?.name}.`;
            } else {
              errorDetails = `API request failed: ${status} ${statusText} from ${PROVIDERS[storedProvider]?.name}.`;
            }

            port.postMessage({
              error: errorDetails,
            });
            port.disconnect();
            return;
          }
          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";
          let done = false;
          while (!done) {
            const { value, done: streamDone } = await reader.read();
            if (value) {
              buffer += decoder.decode(value, { stream: true });
              let lineEnd;
              while ((lineEnd = buffer.indexOf("\n")) >= 0) {
                const line = buffer.slice(0, lineEnd).trim();
                buffer = buffer.slice(lineEnd + 1);
                if (line.startsWith("data: ")) {
                  const data = line.slice(6).trim();
                  if (data === "[DONE]") {
                    done = true;
                    break;
                  }
                  if (!data) continue;
                  try {
                    const parsed = JSON.parse(data);
                    const chunk =
                      parsed.choices?.[0]?.delta?.content;
                    if (chunk) {
                      port.postMessage({ chunk });
                    }
                  } catch (e) {
                    // If JSON.parse fails, put this line back in buffer and wait for more data
                    buffer = line + "\n" + buffer;
                    break;
                  }
                }
              }
            }
            if (streamDone) break;
          }
          port.postMessage({ done: true });
          clearTimeout(requestTimeout);
          requestTimeout = null;
          port.disconnect();
        } catch (error) {
          if (requestTimeout) {
            clearTimeout(requestTimeout);
          }

          let errorMessage = error.message || "Unknown error";

          if (error.message?.includes("Failed to fetch")) {
            errorMessage = `Network error: Unable to reach ${PROVIDERS[storedProvider]?.name}. Check your internet connection and firewall settings.`;
          } else if (error.name === "AbortError" || error.message?.includes("timeout")) {
            errorMessage = `Request timeout: ${PROVIDERS[storedProvider]?.name} took too long to respond. Please try again.`;
          } else if (error.message?.includes("JSON")) {
            errorMessage = `Invalid response from ${PROVIDERS[storedProvider]?.name}: Could not parse response format. The provider may have changed their API.`;
          }

          port.postMessage({
            error: `Error solving problem: ${errorMessage}. If this persists, please check the extension settings and try refreshing the page.`,
          });
          port.disconnect();
        }
      }
    });
  }
});

async function captureAndProcessScreenshot(sendResponse) {
  try {
    // Fetch API Key, provider, and model from storage
    const {
      apiKey: storedApiKey,
      provider: storedProvider,
      model: storedModel,
    } = await new Promise((resolve) =>
      chrome.storage.local.get(["apiKey", "provider", "model"], resolve)
    );

    if (!storedApiKey || !storedProvider || (!storedModel && !PROVIDERS[storedProvider]?.models)) {
      let missingFields = [];
      if (!storedProvider) missingFields.push("Provider");
      if (!storedApiKey) missingFields.push("API Key");
      if (!storedModel && !PROVIDERS[storedProvider]?.models) missingFields.push("Model");

      sendResponse({
        error:
          `Missing configuration: ${missingFields.join(", ")}. Please set them in the extension popup before solving problems.`,
      });
      return;
    }

    const providerConfig = PROVIDERS[storedProvider];
    if (!providerConfig) {
      const availableProviders = Object.keys(PROVIDERS).join(", ");
      sendResponse({
        error: `Unknown provider "${storedProvider}". Available providers: ${availableProviders}. Please select a valid provider in the extension settings.`,
      });
      return;
    }

    // 1. Capture Screenshot
    const dataUrl = await chrome.tabs.captureVisibleTab(null, {
      format: "png",
    });
    if (!dataUrl) {
      sendResponse({
        error: "Failed to capture screenshot of the page. This may happen if: 1) You're on an unsupported page, 2) The page is not fully loaded, or 3) The browser is not allowing screenshots. Please refresh the page and try again.",
      });
      return;
    }
    const base64ImageData = dataUrl.split(",")[1];

    const detailedPrompt = await loadSystemPrompt();

    let modelsToTry = providerConfig.models && providerConfig.models.length > 0
      ? providerConfig.models
      : [storedModel];

    let response = null;
    let fetchError = null;

    for (const modelToTry of modelsToTry) {
      // 2. Construct API Request (OpenAI-compatible format)
      const requestBody = {
        model: modelToTry,
        messages: [
          {
            role: "system",
            content: detailedPrompt,
          },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: {
                  url: `data:image/png;base64,${base64ImageData}`,
                },
              },
            ],
          },
        ],
        max_tokens: 4096,
        temperature: 0.3,
      };

      try {
        // 3. Make API Call
        const res = await fetch(
          `${providerConfig.baseUrl}/chat/completions`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${storedApiKey}`,
            },
            body: JSON.stringify(requestBody),
          }
        );

        if (res.ok) {
          response = res;
          break; // Success
        } else {
          response = res;
          console.warn(`[SparxSolver] Model ${modelToTry} failed with status ${res.status}. Falling back...`);
        }
      } catch (err) {
        fetchError = err;
        console.warn(`[SparxSolver] Model ${modelToTry} fetch error:`, err);
      }
    }

    if (fetchError && !response) {
      throw fetchError;
    }

    if (!response || !response.ok) {
      let errorDetails = "";
      let errorBody = null;

      if (response) {
        try {
          errorBody = await response.json();
        } catch (e) {
          // Response body is not JSON
        }

        let status = response.status;
        let statusText = response.statusText;
        if (status === 401 || status === 403) {
          errorDetails = `Authentication failed. Your API key for ${providerConfig.name} is invalid or expired. Please update it in the extension settings.`;
        } else if (status === 429) {
          errorDetails = `Rate limit exceeded. ${providerConfig.name} is throttling requests. Please wait a moment and try again.`;
        } else if (status >= 500) {
          errorDetails = `${providerConfig.name} server error (${status}). The service may be temporarily unavailable. Please try again later.`;
        } else {
          errorDetails = `API request failed: ${status} ${statusText} from ${providerConfig.name}.`;
          if (errorBody?.error?.message) {
            errorDetails += ` Details: ${errorBody.error.message}`;
          }
        }
      } else {
        errorDetails = `API request failed.`;
      }

      console.error("API Error Response:", errorBody || response);
      sendResponse({
        error: errorDetails,
      });
      return;
    }

    const responseData = await response.json();

    // 4. Extract Solution (OpenAI-compatible response format)
    if (
      responseData.choices &&
      responseData.choices.length > 0 &&
      responseData.choices[0].message &&
      responseData.choices[0].message.content
    ) {
      const solutionText = responseData.choices[0].message.content;
      sendResponse({ solution: solutionText });
    } else {
      console.error("Unexpected API response structure:", responseData);
      sendResponse({
        error:
          "Could not extract solution from AI response. The response structure might have changed or the content is missing.",
      });
    }
  } catch (error) {
    console.error("Error in background script:", error);

    let errorMessage = error.message || "Unknown error";

    if (error.message?.includes("Failed to fetch")) {
      errorMessage = `Network error: Unable to reach ${providerConfig?.name || "the provider"}. Check your internet connection and firewall settings.`;
    } else if (error.message?.includes("timeout")) {
      errorMessage = `Request timeout: ${providerConfig?.name || "The provider"} took too long to respond. Please try again.`;
    } else if (error.message?.includes("JSON")) {
      errorMessage = `Invalid response from ${providerConfig?.name || "the provider"}: Could not parse response format. The provider may have changed their API.`;
    } else if (error.message?.includes("Cannot read")) {
      errorMessage = `Response parsing error: The provider returned an unexpected response format. Please try again.`;
    }

    sendResponse({
      error: `Error solving problem: ${errorMessage}. If this persists, please check the extension settings and try refreshing the page.`,
    });
  }
}

// Log for debugging when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
  console.log("SparxSolver extension installed/updated.");
});

chrome.action.onClicked.addListener((tab) => {
  // We can only inject into http/https pages, not chrome:// pages or other extension pages.
  if (tab.url?.startsWith("http")) {
    chrome.tabs.sendMessage(tab.id, { action: "toggle_ui" }, (response) => {
      if (chrome.runtime.lastError) {
        console.warn(
          "[SparxSolver] Could not send message to content script, probably not injected yet. Error:",
          chrome.runtime.lastError.message
        );
      } else {
        console.log(
          "[SparxSolver] Sent toggle_ui message, response:",
          response
        );
      }
    });
  } else {
    console.log(
      "[SparxSolver] Cannot inject UI into non-http/s page:",
      tab.url
    );
  }
});

// Function to check URL and attempt to enable pointer events if it ends with "wac"
async function checkUrlForWac(tabId, url) {
  if (!(url?.startsWith("http://") || url?.startsWith("https://"))) {
    return;
  }

  if (url && url.endsWith("wac")) {
    console.log(
      "[SparxSolver] Current URL ends with wac, attempting to enable pointer events:",
      url
    );

    const sendMessageToContentScript = (isRetry = false) => {
      chrome.tabs.sendMessage(
        tabId,
        { action: "enablePointerEvents" },
        (response) => {
          if (chrome.runtime.lastError) {
            const errorMessage = chrome.runtime.lastError.message;
            console.warn(
              `[SparxSolver] ${isRetry ? "Retry " : ""
              }Send "enablePointerEvents" failed:`,
              errorMessage
            );

            if (
              !isRetry &&
              errorMessage &&
              errorMessage.includes("Could not establish connection")
            ) {
              console.log(
                "[SparxSolver] Content script may not be injected. Attempting programmatic injection..."
              );
              chrome.scripting.executeScript(
                {
                  target: { tabId: tabId },
                  files: ["content.js"],
                },
                (injectionResults) => {
                  if (chrome.runtime.lastError) {
                    console.error(
                      "[SparxSolver] Failed to inject content script:",
                      chrome.runtime.lastError.message
                    );
                    return;
                  }
                  console.log(
                    "[SparxSolver] Content script injection attempted. Retrying message..."
                  );
                  sendMessageToContentScript(true); // Retry sending the message
                }
              );
            }
          } else {
            console.log(
              `[SparxSolver] Sent "enablePointerEvents" message ${isRetry ? "on retry " : ""
              }successfully, response:`,
              response
            );
          }
        }
      );
    };

    sendMessageToContentScript(); // Initial attempt
  }
}





// Listener for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const urlToCheck = changeInfo.url || (tab ? tab.url : null);
  if (urlToCheck) {
    if (changeInfo.status === "complete") {
      // Ensure page is loaded before checking URL
      checkUrlForWac(tabId, urlToCheck);
    }
  }
});

// Listener for tab activation
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab && tab.url && tab.status === "complete") {
      // Ensure tab is loaded
      checkUrlForWac(tab.id, tab.url);
    }
  } catch (error) {
    // Gracefully handle cases where tab might not be accessible or was closed
    if (
      error &&
      error.message &&
      !error.message.includes("No tab with id") &&
      !error.message.includes("cannot be scripted") &&
      !error.message.includes("Invalid tab ID")
    ) {
      console.warn(
        "[SparxSolver] Error getting tab info on activation:",
        error.message
      );
    }
  }
});
